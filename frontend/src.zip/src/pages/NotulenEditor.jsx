import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Save } from 'lucide-react';

export default function NotulenEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = !!id;

  const [form, setForm] = useState({
    judul: '',
    tanggal: '',
    waktuTempat: '',
    latarBelakang: '',
    pembahasan: '',
    hasilPembahasan: '',
  });

  const handleChange = (field) => (e) => {
    setForm({ ...form, [field]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // TODO: connect ke API Laravel (POST /api/notulen atau PUT /api/notulen/:id)
    console.log('Submit notulen:', form);
    navigate('/notulen');
  };

  return (
    <div className="space-y-4">
      {/* Back */}
      <button
        onClick={() => navigate('/notulen')}
        className="flex items-center gap-1.5 text-sm text-gray-600 hover:text-gray-900"
      >
        <ArrowLeft size={16} strokeWidth={1.75} />
        Kembali ke daftar notulen
      </button>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Header info */}
        <div className="bg-white border border-gray-200 rounded p-5 space-y-4">
          <h2 className="text-sm font-semibold text-gray-800">
            {isEdit ? 'Edit Notulen' : 'Buat Notulen Baru'}
          </h2>

          <Field label="Judul Rapat" value={form.judul} onChange={handleChange('judul')} required />

          <div className="grid grid-cols-2 gap-4">
            <Field label="Tanggal" type="date" value={form.tanggal} onChange={handleChange('tanggal')} required />
            <Field
              label="Waktu / Tempat"
              value={form.waktuTempat}
              onChange={handleChange('waktuTempat')}
              placeholder="09.00 - 11.00 WIB, Ruang Rapat Lantai 3"
            />
          </div>
        </div>

        {/* Content sections */}
        <div className="bg-white border border-gray-200 rounded p-5 space-y-5">
          <TextAreaField
            label="Latar Belakang"
            value={form.latarBelakang}
            onChange={handleChange('latarBelakang')}
          />
          <TextAreaField
            label="Pembahasan"
            value={form.pembahasan}
            onChange={handleChange('pembahasan')}
          />
          <TextAreaField
            label="Hasil Pembahasan / Tindak Lanjut / Kesepakatan"
            value={form.hasilPembahasan}
            onChange={handleChange('hasilPembahasan')}
          />
        </div>

        {/* Attachments placeholder */}
        <div className="bg-white border border-gray-200 rounded p-5 space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-gray-800 mb-2">Daftar Hadir</h3>
            <div className="border border-dashed border-gray-300 rounded p-4 text-center text-sm text-gray-400">
              Unggah foto/scan daftar hadir (belum aktif)
            </div>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-800 mb-2">Dokumentasi (Opsional)</h3>
            <div className="border border-dashed border-gray-300 rounded p-4 text-center text-sm text-gray-400">
              Unggah foto dokumentasi (belum aktif)
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3">
          <button
            type="button"
            onClick={() => navigate('/notulen')}
            className="text-sm border border-gray-300 rounded px-4 py-2 text-gray-600 hover:bg-gray-50"
          >
            Batal
          </button>
          <button
            type="submit"
            className="flex items-center gap-2 text-sm text-white bg-[#0f2557] rounded px-4 py-2 hover:bg-[#0c1e47]"
          >
            <Save size={15} strokeWidth={1.75} />
            Simpan Notulen
          </button>
        </div>
      </form>
    </div>
  );
}

function Field({ label, type = 'text', value, onChange, placeholder = '', required = false }) {
  return (
    <div>
      <label className="block text-xs font-medium text-gray-700 mb-1.5">{label}</label>
      <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        required={required}
        className="w-full px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
      />
    </div>
  );
}

function TextAreaField({ label, value, onChange }) {
  return (
    <div>
      <label className="block text-xs font-medium text-gray-700 mb-1.5">{label}</label>
      <textarea
        value={value}
        onChange={onChange}
        rows={4}
        className="w-full px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 resize-none"
      />
    </div>
  );
}